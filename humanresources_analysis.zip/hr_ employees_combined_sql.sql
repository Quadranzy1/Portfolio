SELECT * FROM projects.hr;

USE projects;
# DATA CLEANING
# I want to have a general overview of my dataset
SELECT * FROM hr;

# Changing the name of my column from ï»¿id to emp_id for easy analysis and limiting it to 20
ALTER TABLE hr
CHANGE COLUMN ï»¿id emp_id VARCHAR(20) NULL;

# To know about my datatype for each column and some othe details about them
DESCRIBE hr;

# Checking the birthdate data which is supposed to be in date type but in text
SELECT birthdate FROM hr;


SET sql_safe_updates = 0;

# Updating the datatype from text to be in date format so that i can change the datatype
UPDATE hr
SET birthdate = CASE
WHEN birthdate LIKE "%/%" THEN date_format(str_to_date(birthdate, "%m/%d/%Y"),"%Y-%m-%d")
WHEN birthdate LIKE "%-%" THEN date_format(str_to_date(birtdate, "%m-%d-%Y"),"%Y-%m-%d")
ELSE NULL
END;

# After updating it, i altered the table
ALTER TABLE hr
MODIFY COLUMN birthdate DATE;

# I crosschecked if the data is in the format i want it 
DESCRIBE hr;

# After checking that, i found out that hire_date column is also in text format
SELECT hire_date FROM hr;

# So i decide to do the change of datatype here also to make my analysis easier
UPDATE hr
SET hire_date = CASE
WHEN hire_date LIKE "%/%" THEN date_format(str_to_date(hire_date, "%m/%d/%Y"),"%Y-%m-%d")
WHEN hire_date LIKE "%-%" THEN date_format(str_to_date(hire_date, "%m-%d-%Y"),"%Y-%m-%d")
ELSE null
END;

# After updating i altered it 
ALTER TABLE hr
MODIFY COLUMN hire_date DATE;

SELECT hire_date FROM hr;

# I also checked for the termdate column
SELECT termdate FROM hr;

# So i updated it also
UPDATE hr
SET termdate = date(str_to_date(termdate, "%Y-%m-%d %H:%i:%s UTC"))
WHERE termdate IS NOT NULL AND termdate != "";

# And after that hen some of the rows are not doing what i want i have to use another code to put it right
UPDATE hr
SET termdate = NULL
WHERE TRIM(termdate) = '';

# And then i altered and update it
ALTER TABLE hr
MODIFY COLUMN termdate DATE;

# Crosschecking
SELECT termdate FROM hr;

# And i checked the whole datatype again and saw that the age of the employees are not provided 
DESCRIBE hr;

# general overview
SELECT * FROM hr;

# So i needed to add an age column to help with my analysis so i did that.
ALTER TABLE hr ADD COLUMN age INT;

# So i make use of the data given me which is the birthdate to get the age using the timestampdiff
UPDATE hr
SET age = timestampdiff(YEAR, birthdate, CURDATE());

# Crosschecking
SELECT birthdate,age FROM hr;

# Before entrying the analysis part i want to be sure if there is no outlier, so i found that there is because under_18 people are working which is not supposed to be
SELECT 
	MIN(age) youngest,
    MAX(age) oldest
FROM hr;

# So i need to know if they can affect the dataset but found out that they are just small
SELECT COUNT(*) FROM hr
WHERE age < 18;

# Exploratory Data Analysis
-- 1. What is the gender breakdown of employees in the company?
SELECt gender, COUNT(*) AS count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY gender;

-- 2. What is the race/ethnicity breakdown of employees in the company?
SELECT race,COUNT(*) AS count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY race
ORDER BY COUNT(*) DESC; 

-- 3. What is the age distribution of employees in the company?
SELECT 
	MIN(age) as youngest,
    MAX(age) as oldest
    FROM hr
    WHERE age >= 18 AND termdate IS NULl;
    
    SELECT 
		CASE 
			WHEN age >= 18 AND age <= 24 THEN "Young Adult"
            WHEN age >= 25 AND age <= 34 THEN "Adult"
            WHEN age >= 35 AND age <= 44 THEN "Mid Adult"
            WHEN age >= 45 AND age <= 54 THEN "Mature Adult"
            WHEN age >= 55 AND age <= 64 THEN "Senior Adult"
            ELSE "Old"
            END AS age_group,
            count(*) AS count
            FROm hr
             WHERE age >= 18 AND termdate IS NULl
             GROUP BY age_group
             ORDER BY age_group;

SELECT 
		CASE 
			WHEN age >= 18 AND age <= 24 THEN "Young Adult"
            WHEN age >= 25 AND age <= 34 THEN "Adult"
            WHEN age >= 35 AND age <= 44 THEN "Mid Adult"
            WHEN age >= 45 AND age <= 54 THEN "Mature Adult"
            WHEN age >= 55 AND age <= 64 THEN "Senior Adult"
            ELSE "Old"
            END AS age_group,gender,
            count(*) AS count
            FROm hr
             WHERE age >= 18 AND termdate IS NULl
             GROUP BY age_group,gender
             ORDER BY age_group,gender;


-- 4. How many employees work at headquarters versus remote locations?
SELECT location, COUNT(*) as count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY location;


-- 5. What is the average length of employment for employees who have been terminated?
SELECT 
ROUND(AVG(datediff(termdate,hire_date))/365,2) as avg_length_employment
FROM hr
WHERE termdate <= CURDATE() and termdate IS NOT NULL AND age >= 18; 

-- 6. How does the gender distribution vary across departments and job titles?
SELECT department,gender,COUNT(*) as count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY department,gender
ORDER BY department;
-- 7. What is the distribution of job titles across the company?
SELECT jobtitle, count(*) as count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY jobtitle
ORDER BY jobtitle DESC;

-- 8. Which department has the highest turnover rate?
SELECT department,
total_count,
terminated_count,
terminated_count/total_count as termination_rate
FROM(
SELECT department,
count(*) as total_count,
SUM(CASE WHEN termdate IS NOT NULL AND termdate <= CURDATE() THEN 1 ELSE 0 END) AS terminated_count
FROM hr
WHERE age >= 18
GROUP BY department
) as subquery
ORDER BY termination_rate DESC;

-- 9. What is the distribution of employees across locations by city and state?
SELECT location_state,COUNT(*) as count
FROM hr
WHERE age >= 18 AND termdate IS NULl
GROUP BY location_state
ORDER BY count DESC;

-- 10. How has the company's employee count changed over time based on hire and term dates?
SELECT 
year,
hires,
terminations,
hires - terminations as net_change,
ROUND((hires - terminations)/hires * 100,2) as net_change_percent
FROM(
	SELECT YEAR(hire_date) as year,
	count(*) as hires,
	SUM(CASE WHEN termdate IS NOT NULL AND termdate <= CURDATE() THEN 1 ELSE 0 END) as terminations
FROM hr
WHERE age >= 18
GROUP BY YEAR(hire_date)
) AS subquery
ORDER BY year ASC;
-- 11. What is the tenure distribution for each department?
SELECT department, round(avg(datediff(termdate,hire_date)/365),2) as avg_tenure
FROM hr
WHERE termdate <= CURDATE() and termdate is not null and age >= 18
GROUP BY department;


SELECT * FROM projects.hr;

USE projects;
# DATA CLEANING
# I want to have a general overview of my dataset
SELECT * FROM hr;

# Changing the name of my column from ï»¿id to emp_id for easy analysis and limiting it to 20
ALTER TABLE hr
CHANGE COLUMN ï»¿id emp_id VARCHAR(20) NULL;

# To know about my datatype for each column and some othe details about them
DESCRIBE hr;

# Checking the birthdate data which is supposed to be in date type but in text
SELECT birthdate FROM hr;


SET sql_safe_updates = 0;

# Updating the datatype from text to be in date format so that i can change the datatype
UPDATE hr
SET birthdate = CASE
WHEN birthdate LIKE "%/%" THEN DATE_FORMAT(STR_TO_DATE(birthdate, "%m/%d/%Y"),"%Y-%m-%d")
WHEN birthdate LIKE "%-%" THEN DATE_FORMAT(STR_TO_DATE(birtdate, "%m-%d-%Y"),"%Y-%m-%d")
ELSE NULL
END;

# After updating it, i altered the table
ALTER TABLE hr
MODIFY COLUMN birthdate DATE;

# I crosschecked if the data is in the format i want it 
DESCRIBE hr;

# After checking that, i found out that hire_date column is also in text format
SELECT hire_date FROM hr;

# So i decide to do the change of datatype here also to make my analysis easier
UPDATE hr
SET hire_date = CASE
WHEN hire_date LIKE "%/%" THEN DATE_FORMAT(STR_TO_DATE(hire_date, "%m/%d/%Y"),"%Y-%m-%d")
WHEN hire_date LIKE "%-%" THEN DATE_FORMAT(STR_TO_DATE(hire_date, "%m-%d-%Y"),"%Y-%m-%d")
ELSE NULL
END;

# After updating i altered it 
ALTER TABLE hr
MODIFY COLUMN hire_date DATE;

SELECT hire_date FROM hr;

# I also checked for the termdate column
SELECT termdate FROM hr;

# So i updated it also
UPDATE hr
SET termdate = DATE(STR_TO_DATE(termdate, "%Y-%m-%d %H:%i:%s UTC"))
WHERE termdate IS NOT NULL AND termdate != "";

# And after that hen some of the rows are not doing what i want i have to use another code to put it right
UPDATE hr
SET termdate = NULL
WHERE TRIM(termdate) = '';

# And then i altered and update it
ALTER TABLE hr
MODIFY COLUMN termdate DATE;

# Crosschecking
SELECT termdate FROM hr;

# And i checked the whole datatype again and saw that the age of the employees are not provided 
DESCRIBE hr;

# general overview
SELECT * FROM hr;

# So i needed to add an age column to help with my analysis so i did that.
ALTER TABLE hr ADD COLUMN age INT;

# So i make use of the data given me which is the birthdate to get the age using the timestampdiff
UPDATE hr
SET age = TIMESTAMPDIFF(YEAR, birthdate, CURDATE());

# Crosschecking
SELECT birthdate,age FROM hr;

# Before entrying the analysis part i want to be sure if there is no outlier, so i found that there is because under_18 people are working which is not supposed to be
SELECT 
	MIN(age) youngest,
    MAX(age) oldest
FROM hr;

# So i need to know if they can affect the dataset but found out that they are just small
SELECT 
    COUNT(*)
FROM
    hr
WHERE
    age < 18;
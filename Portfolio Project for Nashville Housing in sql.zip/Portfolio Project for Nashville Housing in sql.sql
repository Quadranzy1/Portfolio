 /*

 Cleaning Data in SQL Queries

 */


 SELECT * 
 FROM portfolio_project.dbo.Nashville_housing

 -- Standardize Date Format

 SELECT SaleDateConverted, CONVERT(DAte,SaleDate)
 FROM portfolio_project.dbo.Nashville_housing


 Update Nashville_housing
 SET SaleDate = CONVERT(Date,SaleDate)
  
 ALTER TABLE Nashville_housing
 Add SaleDateConverted Date;

  Update Nashville_housing
 SET SaleDateConverted = CONVERT(Date,SaleDate)


 --Populate Property Address data using self join


 SELECT *
 FROM portfolio_project.dbo.Nashville_housing
 --WHERE PropertyAddress IS NULL
 ORDER BY ParcelID

 
 SELECT a.ParcelID, a.PropertyAddress, b.ParcelID, b.PropertyAddress, ISNULL(a.PropertyAddress, b.PropertyAddress )
 FROM portfolio_project.dbo.Nashville_housing a
 JOIN portfolio_project.dbo.Nashville_housing b
     ON a.ParcelID = b.ParcelID
     AND a.[UniqueID ] <> b.[UniqueID ]
     WHERE a.PropertyAddress IS NULL


UPDATE a
SET PropertyAddress = ISNULL(a.PropertyAddress, b.PropertyAddress) --You can also use any other thing you whator set a string there
FROM portfolio_project.dbo.Nashville_housing a
JOIN portfolio_project.dbo.Nashville_housing b
    ON a.ParcelID = b.ParcelID
    AND a.[UniqueID ] <> b.[UniqueID ]
    WHERE a.PropertyAddress IS NULL



--Breaking out Address into Individual Columns (Address, City, State)

SELECT PropertyAddress
 FROM portfolio_project.dbo.Nashville_housing



 SELECT 
 SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress) -1) as Address
 , SUBSTRING(PropertyAddress,CHARINDEX(',',PropertyAddress) +1, LEN(PropertyAddress))  as City
 FROM portfolio_project.dbo.Nashville_housing


  ALTER TABLE Nashville_housing
 Add PropertySplitAddress VARCHAR(255);

  Update Nashville_housing
 SET PropertySplitAddress = SUBSTRING(PropertyAddress, 1, CHARINDEX(',',PropertyAddress) -1)


  ALTER TABLE Nashville_housing
 Add PropertySplitCity VARCHAR(255);

  Update Nashville_housing
 SET PropertySplitCity = SUBSTRING(PropertyAddress,CHARINDEX(',',PropertyAddress) +1, LEN(PropertyAddress))

 SELECT OwnerAddress
 FROM portfolio_project.dbo.Nashville_housing
  

SELECT
PARSENAME(REPLACE(OwnerAddress,',','.'),3),
PARSENAME(REPLACE(OwnerAddress,',','.'),2),
PARSENAME(REPLACE(OwnerAddress,',','.'),1)

 FROM portfolio_project.dbo.Nashville_housing


 ALTER TABLE Nashville_housing
 Add OwnerSplitAddress Nvarchar(255);

  Update Nashville_housing
 SET OwnerSplitAddress = PARSENAME(REPLACE(OwnerAddress,',','.'),3)

  ALTER TABLE Nashville_housing
 Add OwnerSplitCity Nvarchar(255);

  Update Nashville_housing
 SET OwnerSplitCity = PARSENAME(REPLACE(OwnerAddress,',','.'),2)

   ALTER TABLE Nashville_housing
 Add OwnerSplitState Nvarchar(255);

  Update Nashville_housing
 SET OwnerSplitState = PARSENAME(REPLACE(OwnerAddress,',','.'),1)

  SELECT * 
 FROM portfolio_project.dbo.Nashville_housing


 --Change Y and N to Yes and No in "Sold as Vacant" field

  SELECT DISTINCT(SoldAsVacant), COUNT(SoldAsVacant)
 FROM portfolio_project.dbo.Nashville_housing
 GROUP BY SoldAsVacant
 ORDER BY 2


 SELECT SoldAsVacant
, CASE WHEN SoldAsVacant = 'Y' THEN 'Yes'
       WHEN SoldAsVacant = 'N' THEN 'No'
       ELSE SoldAsVacant
       END

FROM portfolio_project.dbo.Nashville_housing 


UPDATE Nashville_housing
SET SoldAsVacant = CASE WHEN SoldAsVacant = 'Y' THEN 'Yes'
       WHEN SoldAsVacant = 'N' THEN 'No'
       ELSE SoldAsVacant
       END




-- Remove Duplicates

WITH RownumCTE AS(
SELECT *,
ROW_NUMBER()OVER(
PARTITION BY ParcelID,
             PropertyAddress,
             SalePrice,
             SaleDate,
             LegalReference
             ORDER BY
               UniqueID
               ) row_num
 FROM portfolio_project.dbo.Nashville_housing
 --ORDER BY ParcelID
 )
 DELETE
 FROM RownumCTE 
 WHERE row_num > 1
-- ORDER BY PropertyAddress

WITH RownumCTE AS(
SELECT *,
ROW_NUMBER()OVER(
PARTITION BY ParcelID,
             PropertyAddress,
             SalePrice,
             SaleDate,
             LegalReference
             ORDER BY
               UniqueID
               ) row_num
 FROM portfolio_project.dbo.Nashville_housing
 --ORDER BY ParcelID
 )
 SELECT *
 FROM RownumCTE 
 WHERE row_num > 1



 --Delete Unused Columns

  SELECT * 
 FROM portfolio_project.dbo.Nashville_housing

 ALTER TABLE portfolio_project.dbo.Nashville_housing
 DROP COLUMN OwnerAddress,TaxDistrict, PropertyAddress

  ALTER TABLE portfolio_project.dbo.Nashville_housing
 DROP COLUMN SaleDate
